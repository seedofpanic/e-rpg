document.addEventListener('DOMContentLoaded', function() {
    // Initialize Socket.IO
    const socket = io();
    const chatContainer = document.getElementById('chat-container');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-btn');
    const continueBtn = document.getElementById('continue-btn');
    const voiceButton = document.getElementById('voice-btn');
    const updateSceneButton = document.getElementById('update-scene-btn');
    const sceneDescription = document.getElementById('scene-description');
    const sceneText = document.getElementById('scene-text');
    const loreText = document.getElementById('lore-text');
    const saveSettingsButton = document.getElementById('save-settings-btn');
    const geminiApiKeyInput = document.getElementById('gemini-api-key');
    const saveGameButton = document.getElementById('save-game-btn');
    const loadGameButton = document.getElementById('load-game-btn');
    const saveFilePathInput = document.getElementById('save-file-path');
    const autosaveEnabledCheckbox = document.getElementById('autosave-enabled');
    const autosaveThresholdInput = document.getElementById('autosave-threshold');
    const confirmResetButton = document.getElementById('confirm-reset-btn');
    const uploadAvatarBtn = document.getElementById('upload-avatar-btn');
    const avatarFile = document.getElementById('avatar-file');
    const avatarPreview = document.getElementById('avatar-preview');
    const avatarPreviewContainer = document.querySelector('.avatar-preview-container');
    const changeGmAvatarBtn = document.getElementById('change-gm-avatar-btn');
    const addCharacterBtn = document.getElementById('add-character-btn');
    const savePartyBtn = document.getElementById('save-party-btn');
    const partyConfigContainer = document.getElementById('party-config-container');
    
    // Persona elements
    const personaDropdown = document.getElementById('persona-dropdown');
    const currentPersonaName = document.getElementById('current-persona-name');
    const currentPersonaAvatar = document.getElementById('current-persona-avatar');
    const personasList = document.getElementById('personas-list');
    const savePersonaBtn = document.getElementById('save-persona-btn');
    const personaNameInput = document.getElementById('persona-name');
    const personaDescriptionInput = document.getElementById('persona-description');
    const personaAvatarPath = document.getElementById('persona-avatar-path');
    const personaAvatarPreview = document.getElementById('persona-avatar-preview');
    const selectPersonaAvatarBtn = document.getElementById('select-persona-avatar-btn');
    const personaAvatarFile = document.getElementById('persona-avatar-file');
    const updatePersonaBtn = document.getElementById('update-persona-btn');
    const deletePersonaBtn = document.getElementById('delete-persona-btn');
    const editPersonaId = document.getElementById('edit-persona-id');
    const editPersonaName = document.getElementById('edit-persona-name');
    const editPersonaDescription = document.getElementById('edit-persona-description');
    const editPersonaAvatarPath = document.getElementById('edit-persona-avatar-path');
    const editPersonaAvatarPreview = document.getElementById('edit-persona-avatar-preview');
    const editSelectPersonaAvatarBtn = document.getElementById('edit-select-persona-avatar-btn');
    const editPersonaAvatarFile = document.getElementById('edit-persona-avatar-file');
    
    // Modal instances
    const avatarUploadModal = new bootstrap.Modal(document.getElementById('avatarUploadModal'));
    const partyConfigModal = new bootstrap.Modal(document.getElementById('partyConfigModal'));
    const personaModal = new bootstrap.Modal(document.getElementById('personaModal'));
    const personaManageModal = new bootstrap.Modal(document.getElementById('personaManageModal'));
    const editPersonaModal = new bootstrap.Modal(document.getElementById('editPersonaModal'));
    
    // Current persona ID
    let currentPersonaId = '';
    
    // Store personas data
    let personasData = {};
    
    // Load personas from server
    loadPersonas();
    
    // Track if system is thinking
    let isThinking = false;
    
    // Store the current characters data
    let charactersData = {};
    
    // Store character IDs with a leader flag
    let partyLeader = null;
    
    // Load saved API key from localStorage if available
    if (localStorage.getItem('geminiApiKey')) {
        geminiApiKeyInput.value = localStorage.getItem('geminiApiKey');
        
        // Send the API key to the server
        socket.emit('update_api_key', { api_key: geminiApiKeyInput.value });
    }
    
    // Load saved file paths from localStorage if available
    if (localStorage.getItem('saveFilePath')) {
        saveFilePathInput.value = localStorage.getItem('saveFilePath');
    } else {
        // Fetch the default save file path from the server
        fetch('/api/get_save_file_path')
            .then(response => response.json())
            .then(data => {
                if (data.filepath) {
                    saveFilePathInput.value = data.filepath;
                    localStorage.setItem('saveFilePath', data.filepath);
                }
            })
            .catch(error => {
                console.error('Error fetching save file path:', error);
            });
    }
    
    // Load autosave settings from the server
    fetch('/api/get_autosave_status')
        .then(response => response.json())
        .then(data => {
            // Check if Flask is running in debug mode
            const isDebugMode = data.debug_mode || false;
            
            // Update autosave status
            autosaveEnabledCheckbox.checked = data.enabled;
            
            // If in debug mode, disable the settings UI and show a message
            if (isDebugMode) {
                // Disable UI elements
                autosaveEnabledCheckbox.disabled = true;
                autosaveThresholdInput.disabled = true;
                
                // Create and add a debug mode message if it doesn't exist
                const settingsContainer = autosaveEnabledCheckbox.closest('.mb-3');
                if (settingsContainer && !document.getElementById('debug-mode-warning')) {
                    const warning = document.createElement('div');
                    warning.id = 'debug-mode-warning';
                    warning.className = 'alert alert-info mt-2 mb-2';
                    warning.style.padding = '0.5rem';
                    warning.innerHTML = '<i class="bi bi-info-circle-fill me-2"></i>Autosave is disabled in debug mode and cannot be enabled.';
                    
                    // Insert after form-check div
                    const formCheck = settingsContainer.querySelector('.form-check');
                    if (formCheck) {
                        formCheck.parentNode.insertBefore(warning, formCheck.nextSibling);
                    } else {
                        settingsContainer.prepend(warning);
                    }
                }
                
                // Add system message
                const systemMessage = 'Flask is running in debug mode. Autosave has been disabled.';
                let hasMessage = false;
                document.querySelectorAll('.system-message p').forEach(p => {
                    if (p.textContent.includes(systemMessage)) {
                        hasMessage = true;
                    }
                });
                if (!hasMessage) {
                    addSystemMessageToChat(systemMessage);
                }
            }
            
            // Get threshold from settings endpoint regardless of debug mode
            return fetch('/api/get_autosave_settings');
        })
        .then(response => response.json())
        .then(data => {
            // Update threshold value
            autosaveThresholdInput.value = data.threshold || 5;
        })
        .catch(error => {
            console.error('Error fetching autosave settings:', error);
        });
    
    // Add event listeners
    sendButton.addEventListener('click', sendMessage);
    document.addEventListener('keypress', function(e) {
        if (e.code === 'Enter' && !isThinking) {
            if (e.ctrlKey) {
                // Send message with continue=true when Ctrl+Enter is pressed
                sendMessage(true);
            } else {
                sendMessage();
            }
        }
    });
    continueBtn.addEventListener('click', continueCampaign);
    voiceButton.addEventListener('click', activateVoiceInput);
    updateSceneButton.addEventListener('click', updateScene);
    saveSettingsButton.addEventListener('click', saveSettings);
    saveGameButton.addEventListener('click', saveGame);
    loadGameButton.addEventListener('click', loadGame);
    confirmResetButton.addEventListener('click', resetGame);
    
    // Add event listener for character active toggle buttons
    document.querySelectorAll('.toggle-active-btn').forEach(button => {
        button.addEventListener('click', toggleCharacterActive);
    });
    
    // Party configuration event listeners
    if (addCharacterBtn) {
        addCharacterBtn.addEventListener('click', addCharacterConfigSlot);
    }
    
    if (savePartyBtn) {
        savePartyBtn.addEventListener('click', savePartyConfiguration);
    }
    
    // Delegate event listener for character removal
    if (partyConfigContainer) {
        partyConfigContainer.addEventListener('click', function(e) {
            if (e.target.classList.contains('remove-character-btn')) {
                const slot = e.target.closest('.character-config-slot');
                if (slot) {
                    slot.remove();
                }
            }
        });
        
        // Delegate event listener for leader selection (only one can be selected)
        partyConfigContainer.addEventListener('change', function(e) {
            if (e.target.classList.contains('character-is-leader') && e.target.checked) {
                document.querySelectorAll('.character-is-leader').forEach(checkbox => {
                    if (checkbox !== e.target) {
                        checkbox.checked = false;
                    }
                });
            }
        });
    }
    
    // Initialize party configuration modal when it's shown
    document.getElementById('partyConfigModal')?.addEventListener('show.bs.modal', function() {
        // Clear existing slots
        partyConfigContainer.innerHTML = '';
        
        // Fetch current characters data from server
        fetch('/api/get_characters')
            .then(response => response.json())
            .then(data => {
                charactersData = data.characters || {};
                
                // Find the current party leader
                for (const charId in charactersData) {
                    if (charactersData[charId].is_leader) {
                        partyLeader = charId;
                        break;
                    }
                }
                
                // Populate character slots
                for (const charId in charactersData) {
                    addCharacterConfigSlot(charactersData[charId]);
                }
            })
            .catch(error => {
                console.error('Error fetching characters:', error);
                addSystemMessageToChat('Failed to load characters data. Please try again.');
            });
    });
    
    // Add event listeners for avatar upload
    document.querySelectorAll('.character-avatar-container').forEach(container => {
        container.addEventListener('click', function() {
            const characterId = this.querySelector('.character-avatar').dataset.characterId;
            document.getElementById('avatar-character-id').value = characterId;
            
            // Reset the file input and preview
            if (avatarFile) {
                avatarFile.value = '';
            }
            if (avatarPreviewContainer) {
                avatarPreviewContainer.classList.add('d-none');
            }
            
            // Show the avatar upload modal
            avatarUploadModal.show();
        });
    });
    
    // Handle file selection for avatar preview
    if (avatarFile) {
        avatarFile.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    avatarPreview.src = e.target.result;
                    avatarPreviewContainer.classList.remove('d-none');
                }
                reader.readAsDataURL(file);
            } else {
                avatarPreviewContainer.classList.add('d-none');
            }
        });
    }
    
    // Handle avatar upload
    if (uploadAvatarBtn) {
        uploadAvatarBtn.addEventListener('click', function() {
            const formData = new FormData(document.getElementById('avatar-upload-form'));
            
            if (!formData.get('avatar') || !formData.get('avatar').name) {
                alert('Please select an image file to upload');
                return;
            }
            
            // Disable the upload button and show loading state
            uploadAvatarBtn.disabled = true;
            uploadAvatarBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
            
            fetch('/api/avatars', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Close the modal
                    avatarUploadModal.hide();
                    
                    // Reload the page to show updated avatar
                    window.location.reload();
                } else {
                    alert('Error uploading avatar: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error uploading avatar:', error);
                alert('Error uploading avatar. Please try again.');
            })
            .finally(() => {
                // Reset button state
                uploadAvatarBtn.disabled = false;
                uploadAvatarBtn.textContent = 'Upload';
            });
        });
    }
    
    // Add event listener for GM avatar button
    if (changeGmAvatarBtn) {
        changeGmAvatarBtn.addEventListener('click', function() {
            document.getElementById('avatar-character-id').value = 'gm';
            document.getElementById('avatarUploadModalLabel').textContent = 'Upload Game Master Avatar';
            
            // Reset the file input and preview
            if (avatarFile) {
                avatarFile.value = '';
            }
            if (avatarPreviewContainer) {
                avatarPreviewContainer.classList.add('d-none');
            }
            
            // Show the avatar upload modal
            avatarUploadModal.show();
        });
    }
    
    // Add event listener for GM avatar container
    const gmAvatarContainer = document.getElementById('gm-avatar-container');
    if (gmAvatarContainer) {
        gmAvatarContainer.addEventListener('click', function() {
            document.getElementById('avatar-character-id').value = 'gm';
            document.getElementById('avatarUploadModalLabel').textContent = 'Upload Game Master Avatar';
            
            // Reset the file input and preview
            if (avatarFile) {
                avatarFile.value = '';
            }
            if (avatarPreviewContainer) {
                avatarPreviewContainer.classList.add('d-none');
            }
            
            // Show the avatar upload modal
            avatarUploadModal.show();
        });
    }
    
    // Add delegation for skill roll menu clicks
    chatContainer.addEventListener('click', function(event) {
        // Check if a skill item was clicked
        if (event.target.classList.contains('skill-item')) {
            // Get character info from the parent roll button
            const rollButton = event.target.closest('.roll-button');
            const characterId = rollButton.dataset.characterId;
            const characterName = rollButton.dataset.characterName;
            const skillName = event.target.dataset.skill;
            
            // Show loading state
            const loadingEl = document.createElement('div');
            loadingEl.className = 'skill-loading';
            loadingEl.textContent = 'Rolling...';
            event.target.appendChild(loadingEl);
            
            // Make socket request to roll the skill
            socket.emit('roll_skill', {
                character_id: characterId,
                skill_name: skillName
            });
            
            // Prevent the menu from closing immediately
            event.stopPropagation();
        }
        
        // Check if a roll button was clicked
        if (event.target.classList.contains('bi-dice-6') || 
            (event.target.closest('.roll-button') && !event.target.classList.contains('skill-item'))) {
            const rollButton = event.target.closest('.roll-button');
            const skillMenu = rollButton.querySelector('.skill-menu');
            
            // Position the menu based on available space
            const buttonRect = rollButton.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            // Get the menu height - we need to make it visible first to calculate its height
            skillMenu.style.display = 'block';
            skillMenu.style.visibility = 'hidden';
            const menuHeight = skillMenu.offsetHeight;
            
            // Check if there's enough space below the button
            const spaceBelow = windowHeight - buttonRect.bottom;
            
            // Reset previous positioning classes
            skillMenu.classList.remove('skill-menu-top', 'skill-menu-bottom');
            
            // If there's not enough space below, position menu above the button
            if (spaceBelow < menuHeight + 10) {
                skillMenu.classList.add('skill-menu-top');
            } else {
                skillMenu.classList.add('skill-menu-bottom');
            }
            
            // Restore visibility but keep it displayed
            skillMenu.style.visibility = '';
            
            // Prevent the event from closing the menu
            event.stopPropagation();
        }
    });
    
    // Add document-wide click listener to close open skill menus when clicking outside
    document.addEventListener('click', function(event) {
        // If not clicking on a roll button or skill menu, close all open menus
        if (!event.target.closest('.roll-button') && !event.target.closest('.skill-menu')) {
            document.querySelectorAll('.skill-menu').forEach(menu => {
                menu.style.display = 'none';
            });
        }
    });
    
    // Socket.IO event handlers
    socket.on('connect', function() {
        console.log('Connected to server');
    });
    
    socket.on('new_message', function(data) {
        if (data.type === 'message') {
            // Pass persona_id to addMessageToChat if it exists
            addMessageToChat(data.sender, data.message, data.character_id, data.avatar);
        } else if (data.type === 'roll') {
            addSkillRollToChat(data);
        } else if (data.type === 'memory') {
            addMemoryMessageToChat(data.sender, data.message, data.avatar);
        } else if (data.type === 'system') {
            addSystemMessageToChat(data.message);
        }
        scrollToBottom();
    });
    
    // Handle thinking event
    socket.on('thinking_started', function() {
        console.log('Thinking started');
        isThinking = true;
        disableSendButton();
        addThinkingMessage();
        scrollToBottom();
    });
    
    // Handle thinking ended event
    socket.on('thinking_ended', function() {
        console.log('Thinking ended');
        isThinking = false;
        enableSendButton();
        removeThinkingMessage();
    });
    
    // Handle rate limit event
    socket.on('rate_limit_reached', function(data) {
        showRateLimitNotification(data.wait_time);
    });
    
    // Add scene updated event handler
    socket.on('scene_updated', function(data) {
        // Update the scene description in the sidebar
        sceneDescription.textContent = data.scene;
    });
    
    // Add character response handler
    socket.on('character_response', function(data) {
        // Remove thinking message if it exists
        removeThinkingMessage();
        
        addMessageToChat(data.character_name, data.message, data.character_id, data.avatar);
        scrollToBottom();
    });
    
    // Add memory added handler
    socket.on('memory_added', function(data) {
        const memoryMessage = `${data.character_name} remembered ${data.memory_item}`;
        addMemoryMessageToChat(data.character_name, memoryMessage, data.character_id);
        scrollToBottom();
    });
    
    // Add characters updated event handler
    socket.on('characters_updated', function(data) {
        // Update stored characters data
        charactersData = data.characters || {};
        
        // Update UI for character active states
        for (const charId in charactersData) {
            const character = charactersData[charId];
            const toggleBtn = document.querySelector(`.toggle-active-btn[data-character-id="${charId}"]`);
            
            if (toggleBtn) {
                // Update data attribute
                toggleBtn.dataset.active = character.active.toString();
                
                // Update icon
                const icon = toggleBtn.querySelector('i');
                if (icon) {
                    if (character.active) {
                        icon.className = 'bi bi-toggle-on text-success';
                        toggleBtn.title = 'Deactivate Character';
                    } else {
                        icon.className = 'bi bi-toggle-off text-secondary';
                        toggleBtn.title = 'Activate Character';
                    }
                }
                
                // Update character item styling
                const characterItem = toggleBtn.closest('.character-item');
                if (characterItem) {
                    if (character.active) {
                        characterItem.classList.remove('character-inactive');
                    } else {
                        characterItem.classList.add('character-inactive');
                    }
                }
            }
        }
    });
    
    // Add scene updating event handler
    socket.on('scene_updating', function(data) {
        const sceneLabel = document.querySelector('.current-scene h5');
        
        if (data.status === 'started') {
            // Add spinner to scene label
            if (sceneLabel) {
                sceneLabel.innerHTML = 'Updating Scene... <div class="spinner-border spinner-border-sm" role="status"><span class="visually-hidden">Loading...</span></div>';
            }
            // Disable scene update button if it exists
            const updateSceneButton = document.querySelector('[data-bs-target="#sceneModal"]');
            if (updateSceneButton) {
                updateSceneButton.disabled = true;
            }
        } else if (data.status === 'completed') {
            // Restore scene label
            if (sceneLabel) {
                sceneLabel.textContent = 'Current Scene';
            }
            // Re-enable scene update button
            const updateSceneButton = document.querySelector('[data-bs-target="#sceneModal"]');
            if (updateSceneButton) {
                updateSceneButton.disabled = false;
            }
        } else if (data.status === 'error') {
            // Show error in scene label
            if (sceneLabel) {
                sceneLabel.innerHTML = 'Scene Update Error <span class="text-danger">⚠️</span>';
                // Add system message about the error
                addSystemMessageToChat('Error updating scene: ' + data.message);
            }
            // Re-enable scene update button
            const updateSceneButton = document.querySelector('[data-bs-target="#sceneModal"]');
            if (updateSceneButton) {
                updateSceneButton.disabled = false;
            }
        }
    });
    
    // Add game reset event handler
    socket.on('game_reset', function() {
        // Clear chat container
        clearChat();
        
        // Add welcome message
        updateWelcomeMessage('Game Reset', 'The game has been reset. Start a new adventure!');
    });
    
    // Functions
    function continueCampaign() {
        if (!isThinking) {
            // Set the thinking state before socket event is received
            isThinking = true;
            disableSendButton();
            addThinkingMessage();
            
            // Emit continue signal to server
            socket.emit('gm_continue');
        }
    }
    
    function showToast(title, message) {
        // Create a Bootstrap toast notification
        const toastId = 'toast-' + Date.now();
        const toastHTML = `
            <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <strong class="me-auto">${title}</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        `;
        
        // Create toast container if it doesn't exist
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        // Add toast to container
        toastContainer.insertAdjacentHTML('beforeend', toastHTML);
        
        // Initialize and show the toast
        const toastElement = document.getElementById(toastId);
        const toast = new bootstrap.Toast(toastElement, {
            autohide: true,
            delay: 3000
        });
        toast.show();
        
        // As a fallback, also add a system message
        addSystemMessageToChat(message);
    }
    
    function sendMessage(continueAfter = false) {
        const message = messageInput.value.trim();
        if (isThinking) return;
        
        // Clear input field
        messageInput.value = '';
        
        // Prepare message data with persona ID
        const messageData = {
            message: message,
            continue: continueAfter
        };
        
        // Add persona ID if using a persona other than default GM
        if (currentPersonaId && currentPersonaId !== 'gm') {
            messageData.persona_id = currentPersonaId;
        }
        
        // Send message to server
        socket.emit('gm_message', messageData);

        if (message === '') {
            if (continueAfter) {
                continueCampaign();
            }
            return;
        }
    }
    
    function disableSendButton() {
        sendButton.disabled = true;
        sendButton.classList.add('disabled');
        continueBtn.disabled = true;
        continueBtn.classList.add('disabled');
        messageInput.placeholder = "Waiting...";
    }
    
    function enableSendButton() {
        sendButton.disabled = false;
        sendButton.classList.remove('disabled');
        continueBtn.disabled = false;
        continueBtn.classList.remove('disabled');
        messageInput.placeholder = "Enter your message as Game Master...";
    }
    
    function updateWelcomeMessage(title, text) {
        const welcomeMessage = document.querySelector('.welcome-message');
        if (welcomeMessage) {
            const h2 = welcomeMessage.querySelector('h2');
            const p = welcomeMessage.querySelector('p');
            const loadingIndicator = welcomeMessage.querySelector('.loading-indicator');
            
            if (h2) h2.textContent = title;
            if (p) p.textContent = text;
            
            // Show or hide loading indicator based on status
            if (loadingIndicator) {
                if (title === 'Model Loading Error') {
                    loadingIndicator.style.display = 'flex';
                } else {
                    loadingIndicator.style.display = 'none';
                }
            }
        }
    }
    
    function showRateLimitNotification(waitTime) {
        // Create rate limit notification
        const notificationDiv = document.createElement('div');
        notificationDiv.className = 'rate-limit-notification';
        notificationDiv.id = 'rate-limit-notification';
        
        // Format the wait time
        const seconds = Math.ceil(waitTime);
        const countdownId = 'countdown-timer';
        
        notificationDiv.innerHTML = `
            <div class="alert alert-warning">
                <strong>Rate limit reached!</strong> Please wait <span id="${countdownId}">${seconds}</span> seconds.
            </div>
        `;
        
        // Style the notification to be fixed at the top
        notificationDiv.style.position = 'sticky';
        notificationDiv.style.top = '0';
        notificationDiv.style.zIndex = '1000';
        notificationDiv.style.width = '100%';
        
        // Add the notification to the top of the chat container
        chatContainer.insertBefore(notificationDiv, chatContainer.firstChild);
        
        // Start countdown timer
        let remainingSeconds = seconds;
        const countdownInterval = setInterval(() => {
            remainingSeconds -= 1;
            const timerElement = document.getElementById(countdownId);
            if (timerElement) {
                timerElement.textContent = remainingSeconds;
            }
            
            if (remainingSeconds <= 0) {
                clearInterval(countdownInterval);
                const notification = document.getElementById('rate-limit-notification');
                if (notification) {
                    notification.remove();
                }
            }
        }, 1000);
    }
    
    function addThinkingMessage() {
        // Remove any existing thinking message first
        removeThinkingMessage();
        
        const thinkingDiv = document.createElement('div');
        thinkingDiv.className = 'message thinking-message';
        thinkingDiv.id = 'thinking-message';
        
        // Add fixed positioning styles - make more visible
        thinkingDiv.style.position = 'fixed';
        thinkingDiv.style.bottom = '20px';
        thinkingDiv.style.left = '50%';
        thinkingDiv.style.transform = 'translateX(-50%)';
        thinkingDiv.style.zIndex = '9999'; // Ensure highest z-index
        thinkingDiv.style.backgroundColor = 'rgba(240, 240, 240, 0.95)';
        thinkingDiv.style.padding = '10px 20px';
        thinkingDiv.style.borderRadius = '10px';
        thinkingDiv.style.boxShadow = '0 3px 8px rgba(0,0,0,0.3)';
        thinkingDiv.style.border = '1px solid rgba(0,0,0,0.1)';
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        const textDiv = document.createElement('div');
        textDiv.className = 'message-text';
        textDiv.textContent = 'Thinking...';
        textDiv.style.fontWeight = 'bold';
        
        contentDiv.appendChild(textDiv);
        thinkingDiv.appendChild(contentDiv);
        
        // Add to body instead of chat container to maintain fixed position
        document.body.appendChild(thinkingDiv);
        
        console.log('Thinking message added', thinkingDiv);
    }
    
    function removeThinkingMessage() {
        const thinkingMessage = document.getElementById('thinking-message');
        if (thinkingMessage) {
            thinkingMessage.remove();
        }
    }
    
    function addMessageToChat(sender, message, character_id, avatar) {
        // Remove thinking message if it exists
        removeThinkingMessage();
        
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message';
        const avatarPath = getAvatarUrl(avatar);
        
        // Handle system messages differently
        if (sender === 'System') {
            messageDiv.className = 'message system-message';
            messageDiv.innerHTML = `
                <div class="message-content">
                    <p>${message}</p>
                </div>
            `;
        } else {            
            messageDiv.innerHTML = `
                <div class="message-avatar">
                    <div class="character-avatar" alt="${sender}" data-character-id="${character_id}" style="background-image: url('${avatarPath}'); width: 64px; height: 64px;"></div>
                </div>
                <div class="message-content">
                    <h5>
                        ${sender}
                        <span class="roll-button" data-character-id="${character_id}" data-character-name="${sender}">
                            <i class="bi bi-dice-6"></i>
                            <div class="skill-menu">
                                <div class="skill-menu-items">
                                    <div class="skill-item" data-skill="acrobatics">Acrobatics</div>
                                    <div class="skill-item" data-skill="animal_handling">Animal Handling</div>
                                    <div class="skill-item" data-skill="arcana">Arcana</div>
                                    <div class="skill-item" data-skill="athletics">Athletics</div>
                                    <div class="skill-item" data-skill="deception">Deception</div>
                                    <div class="skill-item" data-skill="history">History</div>
                                    <div class="skill-item" data-skill="insight">Insight</div>
                                    <div class="skill-item" data-skill="intimidation">Intimidation</div>
                                    <div class="skill-item" data-skill="investigation">Investigation</div>
                                    <div class="skill-item" data-skill="medicine">Medicine</div>
                                    <div class="skill-item" data-skill="nature">Nature</div>
                                    <div class="skill-item" data-skill="perception">Perception</div>
                                    <div class="skill-item" data-skill="performance">Performance</div>
                                    <div class="skill-item" data-skill="persuasion">Persuasion</div>
                                    <div class="skill-item" data-skill="religion">Religion</div>
                                    <div class="skill-item" data-skill="sleight_of_hand">Sleight of Hand</div>
                                    <div class="skill-item" data-skill="stealth">Stealth</div>
                                    <div class="skill-item" data-skill="survival">Survival</div>
                                </div>
                            </div>
                        </span>
                    </h5>
                    <p>${message}</p>
                </div>
            `;
        }
        
        chatContainer.appendChild(messageDiv);
    }
    
    function addSkillRollToChat(data) {
        const rollData = data.data;
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message skill-roll-message';
        
        // Create roll result message with styling based on roll value
        let rollClass = '';
        let rollText = '';
        
        // Determine success/failure/critical based on roll value
        if (rollData.base_roll === 20) {
            rollClass = 'critical-success';
            rollText = 'Critical Success!';
        } else if (rollData.base_roll === 1) {
            rollClass = 'critical-failure';
            rollText = 'Critical Failure!';
        }
        
        // Translate ability name
        const abilityTranslations = {
            'strength': 'Strength',
            'dexterity': 'Dexterity',
            'constitution': 'Constitution',
            'intelligence': 'Intelligence',
            'wisdom': 'Wisdom',
            'charisma': 'Charisma'
        };
        
        const abilityName = abilityTranslations[rollData.ability] || rollData.ability;
        const total = rollData.base_roll + rollData.ability_modifier + rollData.proficiency_bonus;
        
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <div class="character-avatar" alt="${data.sender}" data-character-id="${data.character_id}" style="background-image: url('${getAvatarUrl(data.avatar)}'); width: 64px; height: 64px;"></div>
            </div>
            <div class="message-content">
                <h5>${data.sender}</h5>
                <div class="skill-roll-result">
                    <span class="skill-name">${rollData.skill_name}</span>: 
                    <span class="roll ${rollClass}">
                        <span class="tooltip-container">${total}
                            <span class="tooltip-text">Total result (base roll + ability modifier + proficiency bonus)</span>
                        </span> 
                        <span class="roll-details">(
                            <span class="tooltip-container">${rollData.base_roll}
                                <span class="tooltip-text">d20 roll</span>
                            </span> + 
                            <span class="tooltip-container">${rollData.ability_modifier}
                                <span class="tooltip-text">${abilityName} modifier (${rollData.ability_modifier >= 0 ? '+' : ''}${rollData.ability_modifier})</span>
                            </span> + 
                            <span class="tooltip-container">${rollData.proficiency_bonus}
                                <span class="tooltip-text">Proficiency bonus ${rollData.proficiency_bonus > 0 ? '(character is proficient in this skill)' : '(character is not proficient in this skill)'}</span>
                            </span>
                        )</span>
                    </span>
                    <span class="roll-text ${rollClass}">${rollText}</span>
                </div>
            </div>
        `;
        
        chatContainer.appendChild(messageDiv);
    }
    
    function addMemoryMessageToChat(sender, message, avatar) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message memory-message';
        
        // Format avatar path
        let avatarPath;
        if (avatar && typeof avatar === 'string' && avatar.startsWith('avatars/')) {
            // This is an uploaded avatar
            avatarPath = `/static/images/avatars/${avatar}`;
        } else {
            // This is a default avatar
            avatarPath = `/static/images/${avatar}`;
        }
        
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <div class="character-avatar" alt="${sender}" data-character-id="${avatar}" style="background-image: url('${avatarPath}'); width: 50px; height: 50px;"></div>
            </div>
            <div class="message-content">
                <h5>${sender}</h5>
                <p><i class="memory-icon">📝</i> ${message}</p>
            </div>
        `;
        
        chatContainer.appendChild(messageDiv);
    }
    
    function scrollToBottom() {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
    
    function activateVoiceInput() {
        // Change button appearance to show activation
        voiceButton.classList.add('active');
        voiceButton.innerHTML = '<i class="bi bi-mic-fill" style="color: red;"></i>';
        
        // Make AJAX request to start voice recognition
        fetch('/api/voice_input', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            // Reset button appearance
            voiceButton.classList.remove('active');
            voiceButton.innerHTML = '<i class="bi bi-mic-fill"></i>';
            
            if (data.text) {
                // Fill the input field with recognized text
                messageInput.value = data.text;
            } else if (data.error) {
                console.error('Voice recognition error:', data.error);
                // Show error toast/notification here if needed
            }
        })
        .catch(error => {
            console.error('Error:', error);
            voiceButton.classList.remove('active');
            voiceButton.innerHTML = '<i class="bi bi-mic-fill"></i>';
        });
    }
    
    function updateScene() {
        const newScene = sceneText.value.trim();
        if (newScene) {
            // Close the modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('sceneModal'));
            modal.hide();
            
            // Show updating indicator
            const sceneLabel = document.querySelector('.current-scene h5');
            if (sceneLabel) {
                sceneLabel.innerHTML = 'Updating Scene... <div class="spinner-border spinner-border-sm" role="status"><span class="visually-hidden">Loading...</span></div>';
            }
            
            // Disable scene update button if it exists
            const updateSceneButton = document.querySelector('[data-bs-target="#sceneModal"]');
            if (updateSceneButton) {
                updateSceneButton.disabled = true;
            }
            
            // Make AJAX request to update scene
            fetch('/api/update_game_state', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    scene: newScene
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Update the scene description in the sidebar
                    // Handle both possible response formats
                    if (data.game_state && data.game_state.scene) {
                        sceneDescription.textContent = data.game_state.scene;
                    } else if (data.scene) {
                        sceneDescription.textContent = data.scene;
                    } else {
                        // Fallback to the value we sent
                        sceneDescription.textContent = newScene;
                    }
                    
                    // Update sceneText value to match the current scene
                    sceneText.value = sceneDescription.textContent;
                    
                    // Restore scene label
                    if (sceneLabel) {
                        sceneLabel.textContent = 'Current Scene';
                    }
                    
                    // Re-enable scene update button
                    if (updateSceneButton) {
                        updateSceneButton.disabled = false;
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                
                // Show error in scene label
                if (sceneLabel) {
                    sceneLabel.innerHTML = 'Scene Update Error <span class="text-danger">⚠️</span>';
                    // Add system message about the error
                    addSystemMessageToChat('Error updating scene: ' + error);
                }
                
                // Re-enable scene update button
                if (updateSceneButton) {
                    updateSceneButton.disabled = false;
                }
            });
        }
    }
    
    function addSystemMessageToChat(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message system-message';
        
        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${message}</p>
            </div>
        `;
        
        chatContainer.appendChild(messageDiv);
        scrollToBottom();
    }
    
    function saveSettings() {
        // Get the API key and save it to local storage
        const apiKey = geminiApiKeyInput.value.trim();
        if (apiKey) {
            localStorage.setItem('geminiApiKey', apiKey);
            
            // Send the API key to the server
            socket.emit('update_api_key', { api_key: apiKey });
        }
        
        // Get the file path and save it to local storage
        const filePath = saveFilePathInput.value.trim();
        if (filePath) {
            localStorage.setItem('saveFilePath', filePath);
        }
        
        // Check if we're in debug mode (the checkbox will be disabled)
        const isDebugMode = autosaveEnabledCheckbox.disabled;
        
        // Get the autosave settings
        const autosaveEnabled = isDebugMode ? false : autosaveEnabledCheckbox.checked;
        const autosaveThreshold = parseInt(autosaveThresholdInput.value, 10);
        
        // Update autosave settings on the server
        fetch('/api/update_autosave_settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                enabled: autosaveEnabled,
                threshold: autosaveThreshold
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Autosave settings updated:', data);
            
            // Show message if in debug mode and user tried to enable autosave
            if (data.status === 'warning' && data.message) {
                addSystemMessageToChat(data.message);
            } else {
                // Show success message or update UI if needed
                showToast('Settings Saved', 'Autosave settings have been updated successfully.');
            }
        })
        .catch(error => {
            console.error('Error updating autosave settings:', error);
        });
        
        // Get the base lore text
        const lore = loreText.value.trim();
        
        // Send the update to the server
        fetch('/api/update_game_state', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ lore: lore })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Close the settings modal
                const settingsModal = bootstrap.Modal.getInstance(document.getElementById('settingsModal'));
                settingsModal.hide();
                
                // Add message to chat
                addSystemMessageToChat('Settings updated successfully');
            }
        })
        .catch(error => {
            console.error('Error updating settings:', error);
            addSystemMessageToChat('Error updating settings. Please try again.');
        });
    }
    
    function saveGame() {
        const filepath = saveFilePathInput.value.trim();
        if (!filepath) {
            // Create and display an error alert
            addSystemMessageToChat('Please specify a file path to save the game state.');
            return;
        }
        
        // Save the filepath in localStorage
        localStorage.setItem('saveFilePath', filepath);
        
        // Create saving indicator
        addSystemMessageToChat('Saving game state...');
        
        // Send request to server
        fetch('/api/save_game', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ filepath: filepath })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                addSystemMessageToChat(`Game state saved successfully to: ${data.filepath}`);
            } else {
                addSystemMessageToChat('Error saving game state. Please check the console for details.');
                console.error('Error saving game state:', data);
            }
        })
        .catch(error => {
            addSystemMessageToChat('Error saving game state. Please check the console for details.');
            console.error('Error saving game state:', error);
        });
    }
    
    function loadGame() {
        const filepath = saveFilePathInput.value.trim();
        if (!filepath) {
            // Create and display an error alert
            addSystemMessageToChat('Please specify a file path to load the game state.');
            return;
        }
        
        // Save the filepath in localStorage
        localStorage.setItem('saveFilePath', filepath);
        
        // Clear the chat container except for system messages
        clearChat();
        
        // Create loading indicator
        addSystemMessageToChat('Loading game state...');
        
        // Send request to server
        fetch('/api/load_game', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ filepath: filepath })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                addSystemMessageToChat(`Game state loaded successfully from: ${data.filepath}`);
                
                // Update scene description
                if (data.game_state && data.game_state.scene) {
                    sceneDescription.textContent = data.game_state.scene;
                    sceneText.value = data.game_state.scene;
                }
                
                // Update lore text
                if (data.game_state && data.game_state.lore) {
                    loreText.value = data.game_state.lore;
                }
            } else {
                addSystemMessageToChat('Error loading game state. Please check the console for details.');
                console.error('Error loading game state:', data);
            }
        })
        .catch(error => {
            addSystemMessageToChat('Error loading game state. Please check the console for details.');
            console.error('Error loading game state:', error);
        });
    }
    
    function clearChat() {
        // Remove all messages except the welcome message
        const welcomeMessage = document.querySelector('.welcome-message');
        const systemMessages = Array.from(document.querySelectorAll('.system-message'));
        
        // Clear the chat container
        chatContainer.innerHTML = '';
        
        // Add back welcome message if it exists
        if (welcomeMessage) {
            chatContainer.appendChild(welcomeMessage);
        }
    }
    
    function resetGame() {
        // Call the reset API endpoint
        fetch('/api/reset_game', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update scene description
                sceneDescription.textContent = data.game_state.scene;
                
                // Close the confirmation modal
                const confirmModal = bootstrap.Modal.getInstance(document.getElementById('confirmResetModal'));
                confirmModal.hide();
                
                // Also close the settings modal if it's open
                const settingsModal = bootstrap.Modal.getInstance(document.getElementById('settingsModal'));
                if (settingsModal) {
                    settingsModal.hide();
                }
                
                // Show success notification
                addSystemMessageToChat('Game has been reset successfully');
            } else {
                // Show error
                addSystemMessageToChat('Error resetting game: ' + (data.message || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error resetting game:', error);
            addSystemMessageToChat('Network error while resetting game');
        });
    }
    
    // Toggle character active state
    function toggleCharacterActive(event) {
        const button = event.currentTarget;
        const characterId = button.dataset.characterId;
        const currentActive = button.dataset.active === 'true';
        const newActive = !currentActive;
        
        // Show loading state in the button
        const icon = button.querySelector('i');
        const originalIcon = icon.className;
        icon.className = 'bi bi-hourglass-split';
        button.disabled = true;
        
        // Get the character item for visual feedback
        const characterItem = button.closest('.character-item');
        
        // Call API to toggle active state
        fetch('/api/character/toggle_active', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                character_id: characterId,
                active: newActive
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update button state
                button.dataset.active = newActive.toString();
                
                // Update icon
                if (newActive) {
                    icon.className = 'bi bi-toggle-on text-success';
                    button.title = 'Deactivate Character';
                    
                    // Remove inactive styling
                    if (characterItem) {
                        characterItem.classList.remove('character-inactive');
                    }
                } else {
                    icon.className = 'bi bi-toggle-off text-secondary';
                    button.title = 'Activate Character';
                    
                    // Add inactive styling
                    if (characterItem) {
                        characterItem.classList.add('character-inactive');
                    }
                }
                
                // Add system message
                addSystemMessageToChat(`Character ${characterId} ${newActive ? 'activated' : 'deactivated'}`);
            } else {
                // Restore original icon on error
                icon.className = originalIcon;
                addSystemMessageToChat(data.error || 'Error toggling character active state');
            }
        })
        .catch(error => {
            console.error('Error toggling character active state:', error);
            // Restore original icon on error
            icon.className = originalIcon;
            addSystemMessageToChat('Error toggling character active state');
        })
        .finally(() => {
            // Re-enable button
            button.disabled = false;
        });
    }
    
    // Party configuration functions
    function addCharacterConfigSlot(characterData = null) {
        // Clone the template
        const template = document.getElementById('character-config-template');
        const clone = document.importNode(template.content, true);
        const slot = clone.querySelector('.character-config-slot');
        
        // Set values if character data is provided
        if (characterData) {
            // Fill in character data
            slot.querySelector('.character-id').value = characterData.id || '';
            slot.querySelector('.character-id').readOnly = !!characterData.id; // Make ID read-only for existing characters
            slot.querySelector('.character-name').value = characterData.name || '';
            slot.querySelector('.character-race').value = characterData.race || '';
            slot.querySelector('.character-class').value = characterData.class || '';
            slot.querySelector('.character-personality').value = characterData.personality || '';
            slot.querySelector('.character-background').value = characterData.background || '';
            slot.querySelector('.character-motivation').value = characterData.motivation || '';
            slot.querySelector('.character-is-leader').checked = characterData.is_leader || false;
            slot.querySelector('.character-is-active').checked = characterData.active !== false; // Default to true if undefined
            
            // Set ability scores
            if (characterData.ability_scores) {
                slot.querySelector('.character-strength').value = characterData.ability_scores.strength || 10;
                slot.querySelector('.character-dexterity').value = characterData.ability_scores.dexterity || 10;
                slot.querySelector('.character-constitution').value = characterData.ability_scores.constitution || 10;
                slot.querySelector('.character-intelligence').value = characterData.ability_scores.intelligence || 10;
                slot.querySelector('.character-wisdom').value = characterData.ability_scores.wisdom || 10;
                slot.querySelector('.character-charisma').value = characterData.ability_scores.charisma || 10;
            }
            
            // Set additional character attributes
            if (slot.querySelector('.character-max-hp')) {
                slot.querySelector('.character-max-hp').value = characterData.max_hp || 0;
            }
            if (slot.querySelector('.character-current-hp')) {
                slot.querySelector('.character-current-hp').value = characterData.current_hp || 0;
            }
            if (slot.querySelector('.character-armor-class')) {
                slot.querySelector('.character-armor-class').value = characterData.armor_class || 10;
            }
            if (slot.querySelector('.character-proficiency-bonus')) {
                slot.querySelector('.character-proficiency-bonus').value = characterData.proficiency_bonus || 2;
            }
            
            // Set skill proficiencies if available
            if (characterData.skill_proficiencies && slot.querySelector('.character-skill-proficiencies')) {
                if (typeof characterData.skill_proficiencies === 'object') {
                    // If it's an object with skill keys, handle it
                    const skillCheckboxes = slot.querySelectorAll('.skill-checkbox');
                    skillCheckboxes.forEach(checkbox => {
                        const skillName = checkbox.value;
                        checkbox.checked = characterData.skill_proficiencies[skillName] || false;
                    });
                } else if (Array.isArray(characterData.skill_proficiencies)) {
                    // If it's an array of skill names, handle it
                    const skillCheckboxes = slot.querySelectorAll('.skill-checkbox');
                    skillCheckboxes.forEach(checkbox => {
                        const skillName = checkbox.value;
                        checkbox.checked = characterData.skill_proficiencies.includes(skillName);
                    });
                }
            }
        }
        
        // Add the slot to the container
        partyConfigContainer.appendChild(slot);
    }
    
    function savePartyConfiguration() {
        const slots = document.querySelectorAll('.character-config-slot');
        const characters = {};
        let isValid = true;
        let errorMessage = '';
        
        slots.forEach(slot => {
            const charId = slot.querySelector('.character-id').value.trim();
            const name = slot.querySelector('.character-name').value.trim();
            
            // Validate required fields
            if (!charId || !name) {
                isValid = false;
                errorMessage = 'Character ID and Name are required for all characters.';
                return;
            }
            
            // Check for duplicate IDs
            if (characters[charId]) {
                isValid = false;
                errorMessage = `Duplicate Character ID: ${charId}. Each character must have a unique ID.`;
                return;
            }
            
            // Create character object
            characters[charId] = {
                id: charId,
                name: name,
                race: slot.querySelector('.character-race').value.trim(),
                class: slot.querySelector('.character-class').value.trim(),
                personality: slot.querySelector('.character-personality').value.trim(),
                background: slot.querySelector('.character-background').value.trim(),
                motivation: slot.querySelector('.character-motivation').value.trim(),
                is_leader: slot.querySelector('.character-is-leader').checked,
                active: slot.querySelector('.character-is-active').checked,
                ability_scores: {
                    strength: parseInt(slot.querySelector('.character-strength').value) || 10,
                    dexterity: parseInt(slot.querySelector('.character-dexterity').value) || 10,
                    constitution: parseInt(slot.querySelector('.character-constitution').value) || 10,
                    intelligence: parseInt(slot.querySelector('.character-intelligence').value) || 10,
                    wisdom: parseInt(slot.querySelector('.character-wisdom').value) || 10,
                    charisma: parseInt(slot.querySelector('.character-charisma').value) || 10
                }
            };
            
            // Add additional character attributes if they exist in the UI
            if (slot.querySelector('.character-max-hp')) {
                characters[charId].max_hp = parseInt(slot.querySelector('.character-max-hp').value) || 0;
            }
            if (slot.querySelector('.character-current-hp')) {
                characters[charId].current_hp = parseInt(slot.querySelector('.character-current-hp').value) || 0;
            }
            if (slot.querySelector('.character-armor-class')) {
                characters[charId].armor_class = parseInt(slot.querySelector('.character-armor-class').value) || 10;
            }
            if (slot.querySelector('.character-proficiency-bonus')) {
                characters[charId].proficiency_bonus = parseInt(slot.querySelector('.character-proficiency-bonus').value) || 2;
            }
            
            // Add skill proficiencies if they exist in the UI
            if (slot.querySelector('.skill-checkbox')) {
                const skillCheckboxes = slot.querySelectorAll('.skill-checkbox');
                const skillProficiencies = {};
                
                skillCheckboxes.forEach(checkbox => {
                    const skillName = checkbox.value;
                    skillProficiencies[skillName] = checkbox.checked;
                });
                
                characters[charId].skill_proficiencies = skillProficiencies;
            }
        });
        
        if (!isValid) {
            alert(errorMessage);
            return;
        }
        
        // Check if at least one leader is selected
        const leaderSelected = Object.values(characters).some(char => char.is_leader);
        if (!leaderSelected && Object.keys(characters).length > 0) {
            if (!confirm('No party leader selected. Continue anyway?')) {
                return;
            }
        }
        
        // Send character data to server
        fetch('/api/update_characters', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ characters })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Hide the modal
                partyConfigModal.hide();
                
                // Show success message
                addSystemMessageToChat('Party configuration updated successfully. Reloading page...');
                
                // Reload the page to reflect changes
                setTimeout(() => {
                    window.location.reload();
                }, 1500);
            } else {
                alert('Error updating party: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error updating party:', error);
            alert('Error updating party. Please try again.');
        });
    }
    
    // Handle persona selection from dropdown
    document.addEventListener('click', function(e) {
        // Check if clicked element is a persona item
        if (e.target.closest('.persona-item')) {
            const personaItem = e.target.closest('.persona-item');
            const personaId = personaItem.dataset.personaId;
            
            // Set current persona
            setCurrentPersona(personaId);
        }
    });
    
    // Load personas from server
    function loadPersonas() {
        fetch('/api/get_personas')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    personasData = data.personas || {};
                    
                    // Set default persona
                    setCurrentPersona(data.default_persona || Object.keys(personasData)[0] || '');
                    
                    // Update persona dropdown menu
                    updatePersonaDropdown();
                    
                    // Update persona management list
                    updatePersonasList();
                }
            })
            .catch(error => {
                console.error('Error loading personas:', error);
                addSystemMessageToChat('Failed to load personas. Please try again.');
            });
    }
    
    // Set current persona
    function setCurrentPersona(personaId) {
        currentPersonaId = personaId;
        
        let personaName = '';
        let personaAvatar = 'avatar.jpg';
        
        // Find persona data
        if (personasData[personaId]) {
            personaName = personasData[personaId].name;
            personaAvatar = personasData[personaId].avatar || 'avatar.jpg';
        }
        
        // Update UI
        currentPersonaName.textContent = personaName;
        const avatarUrl = getAvatarUrl(personaAvatar);
        currentPersonaAvatar.src = avatarUrl;
        
        // Update input placeholder
        messageInput.placeholder = personaName ? `Enter your message as ${personaName}...` : 'Enter your message...';

        // Update active state
        personaDropdown.querySelectorAll('.persona-item').forEach(item => {
            if (item.dataset.personaId === personaId) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
        
        // Notify the server about the persona change
        socket.emit('set_current_persona', { persona_id: personaId });
    }
    
    // Get avatar URL
    function getAvatarUrl(avatar) {
        // Handle both formats: "avatar.jpg" and "avatars/persona123.jpg"
        if (avatar.startsWith('avatars/')) {
            return `/static/images/${avatar}`;
        }
        return `/static/images/${avatar}`;
    }
    
    // Update persona dropdown menu
    function updatePersonaDropdown() {
        // Clear all existing items
        personaDropdown.innerHTML = '';
        
        // Add personas to dropdown
        let favoritePersonas = [];
        let regularPersonas = [];
        
        for (const personaId in personasData) {
            const persona = personasData[personaId];
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <a class="dropdown-item persona-item ${personaId === currentPersonaId ? 'active' : ''}" href="#" data-persona-id="${personaId}">
                    <img src="${getAvatarUrl(persona.avatar)}" alt="${persona.name}" class="rounded-circle me-2" width="24" height="24">
                    <span>${persona.name}</span>
                    ${persona.is_favorite ? '<i class="bi bi-star-fill ms-2"></i>' : ''}
                </a>
            `;
            
            // Separate favorites from regular personas
            if (persona.is_favorite) {
                favoritePersonas.push(listItem);
            } else {
                regularPersonas.push(listItem);
            }
        }
        
        // Create a document fragment to hold all new items
        const fragment = document.createDocumentFragment();
        
        // Add favorites and regular personas to the fragment
        favoritePersonas.forEach(item => fragment.appendChild(item));
        regularPersonas.forEach(item => fragment.appendChild(item));
        
        // Add divider if there are any personas
        if (favoritePersonas.length > 0 || regularPersonas.length > 0) {
            const divider = document.createElement('li');
            divider.innerHTML = '<hr class="dropdown-divider">';
            fragment.appendChild(divider);
        }
        
        // Add create and manage options
        const createOption = document.createElement('li');
        createOption.innerHTML = `
            <a class="dropdown-item persona-create" href="#" data-bs-toggle="modal" data-bs-target="#personaModal">
                <i class="bi bi-plus-circle me-2"></i> Create New Persona
            </a>
        `;
        fragment.appendChild(createOption);
        
        const manageOption = document.createElement('li');
        manageOption.innerHTML = `
            <a class="dropdown-item persona-manage" href="#" data-bs-toggle="modal" data-bs-target="#personaManageModal">
                <i class="bi bi-gear me-2"></i> Manage Personas
            </a>
        `;
        fragment.appendChild(manageOption);
        
        // Add all items to the dropdown
        personaDropdown.appendChild(fragment);
        
        // Add event listeners to persona items
        personaDropdown.querySelectorAll('.persona-item').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const personaId = this.dataset.personaId;
                setCurrentPersona(personaId);
            });
        });
    }
    
    // Update personas list in management modal
    function updatePersonasList() {
        personasList.innerHTML = ``;
        
        // Add each persona to the list
        for (const personaId in personasData) {
            const persona = personasData[personaId];
            
            const personaCard = document.createElement('div');
            personaCard.className = 'col-md-6 mb-3';
            personaCard.innerHTML = `
                <div class="card persona-card">
                    <div class="card-body d-flex">
                        <div class="persona-avatar me-3">
                            <img src="${getAvatarUrl(persona.avatar)}" alt="${persona.name}" class="rounded-circle" width="60" height="60">
                        </div>
                        <div class="persona-info flex-grow-1">
                            <h5 class="card-title">${persona.name}</h5>
                            <p class="card-text text-muted small">${persona.description || 'No description'}</p>
                        </div>
                        <div class="persona-actions">
                            <button class="btn btn-sm ${persona.is_favorite ? 'btn-warning' : 'btn-outline-warning'} toggle-favorite-btn" 
                                   title="${persona.is_favorite ? 'Remove from Favorites' : 'Add to Favorites'}" data-persona-id="${personaId}">
                                <i class="bi ${persona.is_favorite ? 'bi-star-fill' : 'bi-star'}"></i>
                            </button>
                            <button class="btn btn-sm ${personaId === currentPersonaId ? 'btn-primary' : 'btn-outline-primary'} set-default-btn" 
                                   title="Set as Default" data-persona-id="${personaId}">
                                <i class="bi bi-bookmark"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-secondary edit-persona-btn" 
                                   title="Edit Persona" data-persona-id="${personaId}">
                                <i class="bi bi-pencil"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            personasList.appendChild(personaCard);
        }
        
        // Add event listeners for persona actions
        personasList.querySelectorAll('.toggle-favorite-btn').forEach(btn => {
            btn.addEventListener('click', togglePersonaFavorite);
        });
        
        personasList.querySelectorAll('.set-default-btn').forEach(btn => {
            btn.addEventListener('click', setDefaultPersona);
        });
        
        personasList.querySelectorAll('.edit-persona-btn').forEach(btn => {
            btn.addEventListener('click', openEditPersonaModal);
        });
    }
    
    // Toggle persona favorite status
    function togglePersonaFavorite(e) {
        const personaId = e.currentTarget.dataset.personaId;
        
        fetch('/api/toggle_persona_favorite', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: personaId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update UI based on server response
                if (personasData[personaId]) {
                    personasData[personaId].is_favorite = data.is_favorite;
                }
                
                // Update persona dropdown and list
                updatePersonaDropdown();
                updatePersonasList();
            }
        })
        .catch(error => {
            console.error('Error toggling persona favorite:', error);
            addSystemMessageToChat('Failed to update persona favorite status.');
        });
    }
    
    // Set default persona
    function setDefaultPersona(e) {
        const personaId = e.currentTarget.dataset.personaId;
        
        fetch('/api/set_default_persona', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: personaId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update UI based on server response
                currentPersonaId = data.default_persona;
                
                // Update persona dropdown and list
                updatePersonaDropdown();
                updatePersonasList();
                
                // Show confirmation message
                addSystemMessageToChat(`Default persona set to ${personasData[personaId].name}.`);
            }
        })
        .catch(error => {
            console.error('Error setting default persona:', error);
            addSystemMessageToChat('Failed to set default persona.');
        });
    }
    
    // Open edit persona modal
    function openEditPersonaModal(e) {
        const personaId = e.currentTarget.dataset.personaId;
        const persona = personasData[personaId];
        
        if (persona) {
            // Fill form with persona data
            editPersonaId.value = personaId;
            editPersonaName.value = persona.name;
            editPersonaDescription.value = persona.description || '';
            editPersonaAvatarPath.value = persona.avatar || 'avatar.jpg';
            editPersonaAvatarPreview.src = getAvatarUrl(persona.avatar || 'avatar.jpg');
            
            // Show modal
            editPersonaModal.show();
        }
    }
    
    // Create new persona
    if (savePersonaBtn) {
        savePersonaBtn.addEventListener('click', function() {
            const name = personaNameInput.value.trim();
            const description = personaDescriptionInput.value.trim();
            const avatar = personaAvatarPath.value;
            
            if (!name) {
                alert('Persona name is required.');
                return;
            }
            
            fetch('/api/create_persona', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name,
                    description,
                    avatar
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Add new persona to personasData
                    personasData[data.persona.id] = data.persona;
                    
                    // Auto-select the newly created persona
                    setCurrentPersona(data.persona.id);
                    
                    // Update persona dropdown and list
                    updatePersonaDropdown();
                    updatePersonasList();
                    
                    // Clear form
                    personaNameInput.value = '';
                    personaDescriptionInput.value = '';
                    personaAvatarPath.value = 'avatar.jpg';
                    personaAvatarPreview.src = getAvatarUrl('avatar.jpg');
                    
                    // Hide modal
                    personaModal.hide();
                    
                    // Show confirmation message
                    addSystemMessageToChat(`Created new persona: ${data.persona.name}`);
                }
            })
            .catch(error => {
                console.error('Error creating persona:', error);
                addSystemMessageToChat('Failed to create persona.');
            });
        });
    }
    
    // Update persona
    if (updatePersonaBtn) {
        updatePersonaBtn.addEventListener('click', function() {
            const personaId = editPersonaId.value;
            const name = editPersonaName.value.trim();
            const description = editPersonaDescription.value.trim();
            const avatar = editPersonaAvatarPath.value;
            
            if (!personaId || !name) {
                alert('Persona ID and name are required.');
                return;
            }
            
            fetch('/api/update_persona', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: personaId,
                    name,
                    description,
                    avatar
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Update persona in personasData
                    personasData[personaId] = data.persona;
                    
                    // Update persona dropdown and list
                    updatePersonaDropdown();
                    updatePersonasList();
                    
                    // Update current persona if it's the one being edited
                    if (currentPersonaId === personaId) {
                        setCurrentPersona(personaId);
                    }
                    
                    // Hide modal
                    editPersonaModal.hide();
                    
                    // Show confirmation message
                    addSystemMessageToChat(`Updated persona: ${data.persona.name}`);
                }
            })
            .catch(error => {
                console.error('Error updating persona:', error);
                addSystemMessageToChat('Failed to update persona.');
            });
        });
    }
    
    // Delete persona
    if (deletePersonaBtn) {
        deletePersonaBtn.addEventListener('click', function() {
            const personaId = editPersonaId.value;
            
            if (!personaId) {
                alert('Persona ID is required.');
                return;
            }
            
            // Confirm deletion
            if (!confirm(`Are you sure you want to delete this persona? This action cannot be undone.`)) {
                return;
            }
            
            fetch('/api/delete_persona', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: personaId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Remove persona from personasData
                    delete personasData[personaId];
                    
                    // Switch to default GM if current persona is deleted
                    if (currentPersonaId === personaId) {
                        setCurrentPersona('gm');
                    }
                    
                    // Update persona dropdown and list
                    updatePersonaDropdown();
                    updatePersonasList();
                    
                    // Hide modal
                    editPersonaModal.hide();
                    
                    // Show confirmation message
                    addSystemMessageToChat(`Deleted persona: ${data.message}`);
                } else {
                    alert(data.message || 'Failed to delete persona.');
                }
            })
            .catch(error => {
                console.error('Error deleting persona:', error);
                addSystemMessageToChat('Failed to delete persona.');
            });
        });
    }
    
    // Avatar file selection for new persona
    if (selectPersonaAvatarBtn && personaAvatarFile) {
        selectPersonaAvatarBtn.addEventListener('click', function() {
            personaAvatarFile.click();
        });
        
        personaAvatarFile.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const formData = new FormData();
                formData.append('avatar', file);
                
                fetch('/api/avatars', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        personaAvatarPath.value = data.avatar_path;
                        personaAvatarPreview.src = getAvatarUrl(data.avatar_path);
                    } else {
                        alert(data.message || 'Failed to upload avatar.');
                    }
                })
                .catch(error => {
                    console.error('Error uploading avatar:', error);
                    alert('Failed to upload avatar.');
                });
            }
        });
    }
    
    // Avatar file selection for edit persona
    if (editSelectPersonaAvatarBtn && editPersonaAvatarFile) {
        editSelectPersonaAvatarBtn.addEventListener('click', function() {
            editPersonaAvatarFile.click();
        });
        
        editPersonaAvatarFile.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const formData = new FormData();
                formData.append('avatar', file);
                
                fetch('/api/avatars', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        editPersonaAvatarPath.value = data.avatar_path;
                        editPersonaAvatarPreview.src = getAvatarUrl(data.avatar_path);
                    } else {
                        alert(data.message || 'Failed to upload avatar.');
                    }
                })
                .catch(error => {
                    console.error('Error uploading avatar:', error);
                    alert('Failed to upload avatar.');
                });
            }
        });
    }
    
    // Handle personas_updated socket event
    socket.on('personas_updated', function(data) {
        personasData = data.personas;
        currentPersonaId = data.default_persona;
        
        // Update UI
        updatePersonaDropdown();
        updatePersonasList();
    });

    // Handle delete character from dropdown menu
    document.querySelector('.delete-character-menu').addEventListener('click', function(e) {
        e.preventDefault();
        
        const characterId = document.querySelector(this).data('character-id');
        
        // Confirm before deletion
        if (confirm(`Are you sure you want to permanently delete character "${characterId}"? This cannot be undone.`)) {
            // Send delete request to server
            fetch('/api/delete_character', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ character_id: characterId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Remove character from UI
                    document.querySelector(`.character-item[data-character-id="${characterId}"]`).remove();
                    addSystemMessageToChat(`Character "${characterId}" deleted successfully.`);
                    
                    // Reload page to update all references
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                } else {
                    alert('Error deleting character: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error deleting character:', error);
                alert('Error deleting character. Please try again.');
            });
        }
    });
}); 